# U N C O V E R

This is my first attempt at building a website, inspired by the Perfect Keto website. The journey to learn web development hasn't been easy. After losing my computer in an accident, I was determined not to give up. I built this U N C O V E R website using the Spck Mobile code editor, making it responsive for both mobile and desktop.

This project is a testament to my resilience and my belief that if you set your mind to something, you can achieve it. Through this process, I learned the fundamentals of HTML and CSS, including how to structure a website, style CSS selectors, and create basic animations.

## Features
- **Responsive Design**: Optimized for both mobile and desktop views.
- **HTML Fundamentals**: Built with a strong foundation in HTML.
- **CSS Styling**: Styled selectors and animations to enhance user experience.

## Acknowledgements
Special thanks to the Perfect Keto website for inspiration.

---

### Built With
- HTML
- CSS
- Spck Mobile Code Editor

---

### Author
**Bob Ombede**